// import { Movies } from './moviesdb/moviesdb.component';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, observable } from 'rxjs';
import { Movies } from './moviesdb/moviesdb';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  url = 'https://api.themoviedb.org';
  params = new HttpParams();
  key = '?api_key=6c02b90ddc8729604c236e52a7399145';
  options = { header: new HttpHeaders({ 'Content-Type': 'application/json' }) };
  constructor(private http: HttpClient) { }
  // tslint:disable-next-line: typedef
  getdata() {
    return this.http.get<Movies>(this.url + '/3/search/movie' + this.key + '&language=en-US&query=year&page=1&include_adult=false');
    // return this.http.get('https://api.themoviedb.org/3/search/movie?api_key=6c02b90ddc8729604c236e52a7399145&language=en-US&query=year&page=1&include_adult=false');
  }
}
