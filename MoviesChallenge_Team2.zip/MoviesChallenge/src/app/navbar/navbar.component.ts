import { Movies } from './../moviesdb/moviesdb';
import { ServiceService } from './../service.service';
// import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent implements OnInit {
  data: Movies;
  message;
  constructor(private ss: ServiceService) { }

  ngOnInit(): void {
    this.ss.getdata().subscribe(resp => { this.data = resp; });
  }
}
