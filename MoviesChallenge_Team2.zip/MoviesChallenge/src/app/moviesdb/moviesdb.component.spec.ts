import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoviesdbComponent } from './moviesdb.component';

describe('MoviesdbComponent', () => {
  let component: MoviesdbComponent;
  let fixture: ComponentFixture<MoviesdbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoviesdbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviesdbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
