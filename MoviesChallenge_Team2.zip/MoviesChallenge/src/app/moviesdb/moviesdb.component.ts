import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Movies } from './moviesdb';

@Component({
  selector: 'app-moviesdb',
  templateUrl: './moviesdb.component.html',
  styleUrls: ['./moviesdb.component.scss']
})
export class MoviesdbComponent implements OnInit {
  data: Movies;
  constructor(private gd: ServiceService) { }
  ngOnInit(): void {
    this.gd.getdata()
    .subscribe((resp: Movies) => {this.data = resp;});
  }

}


